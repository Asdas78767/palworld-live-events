# PalChzzkInteractive 전용 서버 배포 안내

이 배포본은 팰월드 전용 서버 관리자용입니다. 일반 플레이어는 모드를 설치할 필요가 없습니다.

## 포함하지 않는 항목

- config.local.json
- .local 폴더 안의 Client Secret, 브리지 비밀값, 치지직 OAuth 토큰
- node_modules, 로그, 데이터

각 서버 관리자는 자신의 치지직 Developers 애플리케이션과 OAuth 승인을 사용해야 합니다. Client Secret이나 토큰 파일을 다른 사람에게 전달하지 마세요.

## 새 컴퓨터 설치

1. ZIP 파일을 전용 서버 PC에 압축 해제합니다.
2. Node.js 22 이상을 설치한 뒤, 압축 해제한 PalChzzkInteractive 폴더에서 아래를 실행합니다.

    npm ci
    Copy-Item config.example.json config.local.json

3. 치지직 Developers에서 새 앱을 등록합니다.
   - Redirect URI: http://127.0.0.1:18473/callback
   - Scope: 후원 조회
4. .local\chzzk.env.ps1 파일을 새로 만들고 자신의 Client ID, Client Secret, 24자 이상의 무작위 브리지 비밀값을 넣습니다.
5. config.local.json에 자신의 치지직 채널 ID와 팰월드 Player ID를 추가합니다.
6. 전용 서버에 UE4SS와 mod\ue4ss\Mods\PalChzzkInteractive를 설치합니다.
7. 스트리머 계정으로 OAuth 승인을 한 번 완료합니다.

    npm run login -- --streamer streamer-id

8. 전용 서버와 함께 브리지를 실행합니다.

    npm start

## 빠른 사용법

### 최초 1회 설정

1. config.example.json을 config.local.json으로 복사합니다.
2. .local 폴더를 만들고, chzzk.env.example.ps1을 .local\chzzk.env.ps1로 복사합니다.

    New-Item -ItemType Directory .local -Force
    Copy-Item .\chzzk.env.example.ps1 .\.local\chzzk.env.ps1

3. .local\chzzk.env.ps1을 열어 자신의 치지직 Client ID, Client Secret, 24자 이상의 무작위 브리지 비밀값을 입력합니다.
4. config.local.json의 streamers 배열에 방송 정보를 입력합니다. id는 영문과 숫자로 짧게 정하고, channelId에는 치지직 채널 ID, playerUid에는 서버 콘솔에 표시되는 팰월드 Player ID를 넣습니다.

    "streamers": [
      {
        "id": "my-stream",
        "displayName": "내 방송",
        "channelId": "치지직_채널_ID",
        "playerUid": "팰월드_Player_ID",
        "tokenStoreFile": ".local/chzzk-token-my-stream.json"
      }
    ]

### 치지직 로그인

설정한 스트리머마다 아래 명령을 한 번 실행합니다. 브라우저가 열리면 해당 치지직 계정으로 로그인하고 후원 조회 권한을 승인합니다. 성공 후에는 토큰이 이 PC의 .local 폴더에만 저장됩니다.

    .\login-chzzk.ps1 -StreamerId my-stream

### 방송할 때 실행

1. 팰월드 전용 서버를 먼저 실행하고 플레이어가 접속할 수 있는 상태인지 확인합니다.
2. 별도의 PowerShell 창에서 PalChzzkInteractive 폴더를 열고 아래 명령을 실행합니다.

    .\run-live.ps1

3. 그 PowerShell 창을 켜 둔 채 방송합니다. 치지직 후원이 들어오면 rules.example.json의 금액 규칙에 따라 명령이 처리됩니다.

중지하려면 브리지 PowerShell 창에서 Ctrl+C를 누릅니다. 전용 서버는 별도로 종료해야 합니다.

### 후원 규칙 바꾸기

rules.example.json에서 금액과 동작을 수정할 수 있습니다. config.local.json의 rulesFile 값이 rules.example.json을 가리키는지 확인하고, 규칙을 변경한 뒤에는 브리지를 다시 실행합니다.

자동 명령을 멈추려면 config.local.json의 safety 항목에서 emergencyStop을 true로 바꾼 뒤 브리지를 다시 실행합니다.

## 여러 스트리머

config.local.json의 streamers 배열에 스트리머를 추가합니다. 각 항목에는 서로 다른 id, channelId, playerUid, tokenStoreFile이 필요합니다. 각 스트리머 계정으로 OAuth 승인을 한 번씩 실행하면 됩니다.

    npm run login -- --streamer second-streamer-id

## 배포본 다시 만들기

프로젝트 폴더에서 아래 명령을 실행하면 release 폴더에 새 ZIP이 생성됩니다.

    .\tools\New-DistributionPackage.ps1

## 현재 게임 연동 범위

브리지는 치지직 OAuth, 후원 구독, 규칙 매칭, 서명된 명령 전달까지 포함합니다. 현재 UE4SS 부분은 로더와 통신 규약 확인 단계이므로, 실제 게임 내 효과 어댑터는 전용 서버 버전에서 별도로 검증해야 합니다. 게임 효과가 완성되었다고 표시해 배포하면 안 됩니다.
