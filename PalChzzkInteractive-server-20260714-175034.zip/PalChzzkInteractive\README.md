# PalStream Interactive (PalChzzk)

치지직 후원 이벤트를 허용 목록 방식의 팰월드 전용 서버 명령으로 바꾸는 0.1 구현입니다.

- 정확한 금액·최소 금액·금액 구간 규칙과 우선순위
- HMAC 서명, 시간 제한, 중복 요청 방지 로컬 TCP 규약
- 가상 후원 전송기와 모의 팰월드 모드
- 치지직 OAuth 로그인, 토큰 갱신, 공식 세션·후원 구독 어댑터
- UE4SS 연동을 위한 로더 확인 스크립트와 안전한 명령 허용 목록

## 로컬 검증

```powershell
Set-Location 'C:\Users\Mingy\OneDrive\Desktop\PalworldModdingKit-62fad4130238cb0aadf024b87496e7387d5f4bf5\PalChzzkInteractive'
$env:PALCHZZK_BRIDGE_SECRET = '개발용으로만_24자_이상의_무작위_문자열'
npm test
```

가상 후원은 다음처럼 검증합니다.

```powershell
Copy-Item config.example.json config.local.json
$env:PALCHZZK_BRIDGE_SECRET = '동일한_24자_이상의_개발용_비밀값'
npm run mock-mod
# 새 PowerShell 창에서
npm run test:donation -- --amount 3000 --message 불
```

## 실제 치지직 연결

1. 개발자 센터에서 앱을 `PalStream Interactive`처럼 등록합니다. 앱 ID/이름에 `chzzk`, `치지직`, `naver`, `네이버`를 넣으면 안 됩니다.
2. Redirect URI를 `http://127.0.0.1:18473/callback`로 등록하고 `config.local.json`의 `channelId`를 방송 채널 ID로 채웁니다.
3. 환경 변수에 `PALCHZZK_CLIENT_ID`, `PALCHZZK_CLIENT_SECRET`, `PALCHZZK_BRIDGE_SECRET`를 설정합니다.
4. `npm run login`으로 방송인 계정의 승인을 완료한 뒤 `config.local.json`에서 `chzzk.enabled`를 `true`로 바꿉니다.
5. 실제 전용 서버 모드가 준비된 뒤 `npm start`로 브리지를 실행합니다.

토큰은 무시되는 `.local/chzzk-token.json`에만 저장되며, 설정 파일이나 배포물에 넣지 않습니다.

게임 내부 연동은 UE4SS에서 현재 전용 서버 버전을 대상으로 검증한 다음에만 활성화합니다. 초기 UE4SS 스크립트는 로더와 명령 규약 확인용이며 임의 게임 함수를 호출하지 않습니다. 자세한 내용은 [치지직 연결](docs/CHZZK_CONNECT_KO.md), [아키텍처](docs/architecture.md), [게임 모드 연동](mod/ue4ss/README.md)을 참고하세요.
