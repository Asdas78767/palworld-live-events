import { randomUUID } from 'node:crypto';
import type { DonationEvent } from './domain.ts';

export function makeAdminDonation(amount: number, message = '', viewer = '시험 시청자'): DonationEvent {
  if (!Number.isSafeInteger(amount) || amount < 1) {
    throw new Error('Donation amount must be a positive integer.');
  }
  return {
    eventId: `admin-${randomUUID()}`,
    eventType: 'DONATION',
    receivedAt: new Date().toISOString(),
    viewer: { nickname: viewer, anonymous: false },
    amount,
    message,
  };
}
