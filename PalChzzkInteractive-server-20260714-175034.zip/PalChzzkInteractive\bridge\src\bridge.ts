import type { BridgeConfig, CommandResult, DonationEvent } from './domain.ts';
import { buildCommand } from './command-builder.ts';
import { LocalModClient } from './mod-client.ts';
import { DonationRuleEngine } from './rule-engine.ts';
import { resolveDonationTarget } from './streamer-routing.ts';

export type BridgeProcessResult =
  | { status: 'IGNORED'; reason: string }
  | { status: 'BLOCKED'; reason: string }
  | { status: 'EXECUTED'; ruleId: string; result: CommandResult };

export class PalChzzkBridge {
  private readonly config: BridgeConfig;
  private readonly secret: string;
  private readonly ruleEngine: DonationRuleEngine;
  private readonly modClient: LocalModClient;

  constructor(
    config: BridgeConfig,
    secret: string,
    ruleEngine: DonationRuleEngine,
    modClient: LocalModClient,
  ) {
    this.config = config;
    this.secret = secret;
    this.ruleEngine = ruleEngine;
    this.modClient = modClient;
  }

  async processDonation(event: DonationEvent): Promise<BridgeProcessResult> {
    if (this.config.safety.emergencyStop) {
      return { status: 'BLOCKED', reason: 'Emergency stop is active.' };
    }

    const target = resolveDonationTarget(this.config, event);
    if (!target.success) return { status: 'BLOCKED', reason: target.reason };

    const action = this.ruleEngine.match(event);
    if (!action) return { status: 'IGNORED', reason: 'No donation rule matched this event.' };

    if (this.config.safety.safeMode && action.type !== 'ANNOUNCE' && action.type !== 'QUERY_PLAYER_STATUS') {
      return { status: 'BLOCKED', reason: `Safe mode blocks ${action.type}.` };
    }

    if (action.type === 'SPAWN_ENEMY') {
      const count = Number(action.parameters.count);
      if (!Number.isInteger(count) || count < 1 || count > this.config.limits.maximumSpawnPerAction) {
        return { status: 'BLOCKED', reason: `Spawn count must be between 1 and ${this.config.limits.maximumSpawnPerAction}.` };
      }
    }

    const command = buildCommand(this.secret, event, action, target.target);
    const result = await this.modClient.send(command);
    return { status: 'EXECUTED', ruleId: action.ruleId, result };
  }

  close(): void {
    this.modClient.close();
  }
}
