import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import { resolve } from 'node:path';
import type { BridgeConfig } from './domain.ts';
import { ChzzkTokenStore, type ChzzkToken } from './chzzk-token-store.ts';
import { selectChzzkSubscription, type ChzzkSubscription } from './streamer-routing.ts';

const openApiBaseUrl = 'https://openapi.chzzk.naver.com';

function getChzzkConfig(config: BridgeConfig): NonNullable<BridgeConfig['chzzk']> {
  if (!config.chzzk) throw new Error('Add the chzzk configuration block before using CHZZK login.');
  return config.chzzk;
}

function requiredEnvironment(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Set ${name} as an environment variable. Do not place it in config.local.json.`);
  return value;
}

function unwrapTokenResponse(body: unknown): ChzzkToken {
  const payload = body && typeof body === 'object' && !Array.isArray(body) && 'content' in body
    ? (body as { content: unknown }).content
    : body;
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('CHZZK returned an invalid token response.');
  const token = payload as Record<string, unknown>;
  const accessToken = token.accessToken;
  const refreshToken = token.refreshToken;
  const expiresIn = Number(token.expiresIn);
  if (typeof accessToken !== 'string' || typeof refreshToken !== 'string' || !Number.isFinite(expiresIn)) {
    throw new Error('CHZZK token response was missing accessToken, refreshToken, or expiresIn.');
  }
  return { accessToken, refreshToken, expiresAt: Date.now() + Math.max(1, expiresIn - 60) * 1000 };
}

async function requestToken(body: Record<string, string>): Promise<ChzzkToken> {
  const response = await fetch(`${openApiBaseUrl}/auth/v1/token`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const payload: unknown = await response.json().catch(() => undefined);
  if (!response.ok) throw new Error(`CHZZK token request failed with HTTP ${response.status}.`);
  return unwrapTokenResponse(payload);
}

function localCallback(redirectUri: string): URL {
  const callback = new URL(redirectUri);
  const permitted = callback.protocol === 'http:' && (callback.hostname === '127.0.0.1' || callback.hostname === 'localhost');
  if (!permitted || !callback.port) throw new Error('redirectUri must be an exact local HTTP URL such as http://127.0.0.1:18473/callback.');
  return callback;
}

function tokenStore(baseDirectory: string, subscription: ChzzkSubscription): ChzzkTokenStore {
  return new ChzzkTokenStore(resolve(baseDirectory, subscription.tokenStoreFile));
}

export async function getAccessToken(config: BridgeConfig, baseDirectory: string, subscription: ChzzkSubscription): Promise<string> {
  const chzzk = getChzzkConfig(config);
  const store = tokenStore(baseDirectory, subscription);
  const existing = await store.load();
  if (existing && existing.expiresAt > Date.now()) return existing.accessToken;
  if (!existing) throw new Error('No CHZZK login token is available. Run npm run login first.');

  const refreshed = await requestToken({
    grantType: 'refresh_token',
    refreshToken: existing.refreshToken,
    clientId: requiredEnvironment(chzzk.clientIdEnvironmentName),
    clientSecret: requiredEnvironment(chzzk.clientSecretEnvironmentName),
  });
  await store.save(refreshed);
  return refreshed.accessToken;
}

export async function loginWithChzzk(config: BridgeConfig, baseDirectory: string, streamerId?: string): Promise<void> {
  const chzzk = getChzzkConfig(config);
  const subscription = selectChzzkSubscription(config, streamerId);
  const callback = localCallback(chzzk.redirectUri);
  const state = randomBytes(32).toString('base64url');
  const authorizationUrl = new URL('https://chzzk.naver.com/account-interlock');
  authorizationUrl.searchParams.set('clientId', requiredEnvironment(chzzk.clientIdEnvironmentName));
  authorizationUrl.searchParams.set('redirectUri', chzzk.redirectUri);
  authorizationUrl.searchParams.set('state', state);

  const result = await new Promise<{ code: string; state: string }>((resolveLogin, rejectLogin) => {
    const server = createServer((request, response) => {
      const requestUrl = new URL(request.url ?? '/', chzzk.redirectUri);
      if (requestUrl.pathname !== callback.pathname) {
        response.writeHead(404).end('Not found');
        return;
      }
      const code = requestUrl.searchParams.get('code');
      const returnedState = requestUrl.searchParams.get('state');
      if (!code || !returnedState || returnedState !== state) {
        response.writeHead(400, { 'content-type': 'text/plain; charset=utf-8' }).end('Login verification failed. You may close this window.');
        server.close(() => rejectLogin(new Error('CHZZK login state verification failed.')));
        return;
      }
      response.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }).end('CHZZK 로그인 완료. 이 창을 닫고 PowerShell로 돌아가세요.');
      server.close(() => resolveLogin({ code, state: returnedState }));
    });
    server.once('error', rejectLogin);
    server.listen(Number(callback.port), callback.hostname, () => {
      console.log('Open this URL in the broadcaster\'s browser, then approve the requested CHZZK permissions:');
      console.log(authorizationUrl.toString());
    });
  });

  const token = await requestToken({
    grantType: 'authorization_code',
    clientId: requiredEnvironment(chzzk.clientIdEnvironmentName),
    clientSecret: requiredEnvironment(chzzk.clientSecretEnvironmentName),
    code: result.code,
    state: result.state,
  });
  await tokenStore(baseDirectory, subscription).save(token);
  console.log(`CHZZK login completed for ${subscription.displayName}. The token was stored only in the ignored local token store.`);
}
