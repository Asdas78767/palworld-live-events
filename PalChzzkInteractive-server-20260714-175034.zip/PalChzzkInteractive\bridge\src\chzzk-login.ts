import { resolve } from 'node:path';
import { loadConfig } from './config.ts';
import { loginWithChzzk } from './chzzk-auth.ts';

function argumentValue(name: string): string | undefined {
  const index = process.argv.indexOf(name);
  return index === -1 ? undefined : process.argv[index + 1];
}

const configPath = resolve(argumentValue('--config') ?? 'config.local.json');
const { config, baseDirectory } = await loadConfig(configPath);
await loginWithChzzk(config, baseDirectory, argumentValue('--streamer'));
