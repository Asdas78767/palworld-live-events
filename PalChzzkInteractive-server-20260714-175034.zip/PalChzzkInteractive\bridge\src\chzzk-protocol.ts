import { createHash, randomUUID } from 'node:crypto';
import type { DonationEvent } from './domain.ts';

export type EnginePacket =
  | { kind: 'OPEN'; data: Record<string, unknown> }
  | { kind: 'PING' }
  | { kind: 'PONG' }
  | { kind: 'NAMESPACE_CONNECTED' }
  | { kind: 'EVENT'; eventName: string; data: unknown }
  | { kind: 'UNKNOWN'; raw: string };

function record(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
}

export function buildChzzkSocketUrl(sessionUrl: string): string {
  const url = new URL(sessionUrl);
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    throw new Error('CHZZK session URL must use HTTP or HTTPS.');
  }
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  const basePath = url.pathname.replace(/\/$/, '');
  url.pathname = `${basePath}/socket.io/`;
  url.searchParams.set('EIO', '3');
  url.searchParams.set('transport', 'websocket');
  return url.toString();
}

export function parseEnginePacket(raw: string): EnginePacket {
  if (raw === '2') return { kind: 'PING' };
  if (raw === '3') return { kind: 'PONG' };
  if (raw === '40') return { kind: 'NAMESPACE_CONNECTED' };
  if (raw.startsWith('0')) {
    const data = record(JSON.parse(raw.slice(1))) ?? {};
    return { kind: 'OPEN', data };
  }
  if (raw.startsWith('42')) {
    const event = JSON.parse(raw.slice(2));
    if (Array.isArray(event) && typeof event[0] === 'string') {
      return { kind: 'EVENT', eventName: event[0], data: event[1] };
    }
  }
  return { kind: 'UNKNOWN', raw };
}

function stringValue(value: unknown, maximumLength = 500): string {
  return typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, maximumLength) : '';
}

function donationEventId(payload: Record<string, unknown>): string {
  const supplied = payload.donationId ?? payload.eventId ?? payload.id;
  if (typeof supplied === 'string' && supplied.length > 0) return `chzzk-${supplied}`;
  // CHZZK's documented donation body does not expose a stable event ID. Do not
  // fingerprint it: two legitimate equal donations must remain two events.
  return `chzzk-${randomUUID()}`;
}

export function normalizeChzzkDonation(payload: unknown): DonationEvent | undefined {
  const source = record(payload);
  if (!source) return undefined;
  const amount = Number(source.payAmount);
  if (!Number.isSafeInteger(amount) || amount < 1) return undefined;

  const viewerId = stringValue(source.donatorChannelId, 128);
  const nickname = stringValue(source.donatorNickname, 80) || '익명 후원자';
  return {
    eventId: donationEventId(source),
    eventType: 'DONATION',
    receivedAt: new Date().toISOString(),
    channelId: stringValue(source.channelId, 128) || undefined,
    viewer: { id: viewerId || undefined, nickname, anonymous: !viewerId },
    amount,
    message: stringValue(source.donationText),
  };
}

export function shortEventFingerprint(value: unknown): string {
  return createHash('sha256').update(JSON.stringify(value) ?? String(value)).digest('hex').slice(0, 12);
}
