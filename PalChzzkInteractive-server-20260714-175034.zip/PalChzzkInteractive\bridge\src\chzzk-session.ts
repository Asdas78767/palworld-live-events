import type { BridgeConfig, DonationEvent } from './domain.ts';
import { getAccessToken } from './chzzk-auth.ts';
import { buildChzzkSocketUrl, normalizeChzzkDonation, parseEnginePacket, shortEventFingerprint } from './chzzk-protocol.ts';
import type { ChzzkSubscription } from './streamer-routing.ts';

const openApiBaseUrl = 'https://openapi.chzzk.naver.com';

type StatusHandler = (message: string) => void;
type DonationHandler = (event: DonationEvent) => Promise<void>;

function record(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
}

function sessionUrlFromResponse(body: unknown): string {
  const outer = record(body);
  const content = record(outer?.content ?? body);
  if (!content || typeof content.url !== 'string') throw new Error('CHZZK did not return a session URL.');
  return content.url;
}

export class ChzzkDonationSession {
  private readonly bridgeConfig: BridgeConfig;
  private readonly subscription: ChzzkSubscription;
  private readonly baseDirectory: string;
  private readonly onDonation: DonationHandler;
  private readonly onStatus: StatusHandler;
  private socket?: WebSocket;
  private reconnectDelayMilliseconds = 1000;
  private reconnectTimer?: ReturnType<typeof setTimeout>;
  private stopped = false;

  constructor(bridgeConfig: BridgeConfig, subscription: ChzzkSubscription, baseDirectory: string, onDonation: DonationHandler, onStatus: StatusHandler = console.log) {
    this.bridgeConfig = bridgeConfig;
    this.subscription = subscription;
    this.baseDirectory = baseDirectory;
    this.onDonation = onDonation;
    this.onStatus = onStatus;
  }

  async start(): Promise<void> {
    this.stopped = false;
    await this.connectOnce();
  }

  stop(): void {
    this.stopped = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.socket?.close();
    this.socket = undefined;
  }

  private async connectOnce(): Promise<void> {
    const accessToken = await getAccessToken(this.bridgeConfig, this.baseDirectory, this.subscription);
    const response = await fetch(`${openApiBaseUrl}/open/v1/sessions/auth`, {
      headers: { authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
    });
    const body: unknown = await response.json().catch(() => undefined);
    if (!response.ok) throw new Error(`CHZZK session creation failed with HTTP ${response.status}.`);
    const socketUrl = buildChzzkSocketUrl(sessionUrlFromResponse(body));
    const socket = new WebSocket(socketUrl);
    this.socket = socket;

    socket.addEventListener('open', () => {
      this.reconnectDelayMilliseconds = 1000;
      socket.send('40');
      this.onStatus(`[${this.subscription.id}] CHZZK session socket connected; waiting for the session key.`);
    });
    socket.addEventListener('message', (event) => void this.handleMessage(String(event.data), accessToken));
    socket.addEventListener('error', () => this.onStatus('CHZZK session socket reported an error.'));
    socket.addEventListener('close', () => this.scheduleReconnect());
  }

  private async handleMessage(raw: string, accessToken: string): Promise<void> {
    let packet;
    try {
      packet = parseEnginePacket(raw);
    } catch {
      this.onStatus(`Ignored malformed CHZZK socket packet (${shortEventFingerprint(raw)}).`);
      return;
    }
    if (packet.kind === 'PING') {
      this.socket?.send('3');
      return;
    }
    if (packet.kind === 'EVENT' && packet.eventName === 'SYSTEM') {
      const system = record(packet.data);
      if (system?.type === 'connected') {
        const data = record(system.data);
        const sessionKey = data?.sessionKey;
        if (typeof sessionKey !== 'string') throw new Error('CHZZK connected message did not contain sessionKey.');
        await this.subscribeToDonations(sessionKey, accessToken);
        this.onStatus(`[${this.subscription.id}] CHZZK donation subscription is active.`);
      }
      if (system?.type === 'revoked') this.onStatus('CHZZK authorization was revoked; run npm run login again.');
      return;
    }
    if (packet.kind === 'EVENT' && packet.eventName === 'DONATION') {
      const donation = normalizeChzzkDonation(packet.data);
      if (!donation) {
        this.onStatus(`Ignored malformed CHZZK donation (${shortEventFingerprint(packet.data)}).`);
        return;
      }
      if (donation.channelId !== this.subscription.channelId) return;
      await this.onDonation(donation);
    }
  }

  private async subscribeToDonations(sessionKey: string, accessToken: string): Promise<void> {
    const response = await fetch(`${openApiBaseUrl}/open/v1/sessions/events/subscribe/donation`, {
      method: 'POST',
      headers: { authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
      body: JSON.stringify({ sessionKey }),
    });
    if (!response.ok) throw new Error(`CHZZK donation subscription failed with HTTP ${response.status}.`);
  }

  private scheduleReconnect(): void {
    if (this.stopped) return;
    const delay = this.reconnectDelayMilliseconds;
    this.reconnectDelayMilliseconds = Math.min(this.reconnectDelayMilliseconds * 2, 30_000);
    this.onStatus(`CHZZK connection closed. Reconnecting in ${Math.round(delay / 1000)}s.`);
    this.reconnectTimer = setTimeout(() => {
      void this.connectOnce().catch((error: unknown) => {
        this.onStatus(`CHZZK reconnect failed: ${error instanceof Error ? error.message : String(error)}`);
        this.scheduleReconnect();
      });
    }, delay);
    this.reconnectTimer.unref();
  }
}
