import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

export interface ChzzkToken {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
}

export class ChzzkTokenStore {
  private readonly filePath: string;

  constructor(filePath: string) {
    this.filePath = filePath;
  }

  async load(): Promise<ChzzkToken | undefined> {
    try {
      const parsed: unknown = JSON.parse(await readFile(this.filePath, 'utf8'));
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return undefined;
      const token = parsed as Partial<ChzzkToken>;
      if (typeof token.accessToken !== 'string' || typeof token.refreshToken !== 'string' || !Number.isSafeInteger(token.expiresAt)) return undefined;
      return token as ChzzkToken;
    } catch (error: unknown) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined;
      throw new Error(`Could not read the CHZZK token store: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async save(token: ChzzkToken): Promise<void> {
    await mkdir(dirname(this.filePath), { recursive: true });
    await writeFile(this.filePath, JSON.stringify(token, null, 2), { encoding: 'utf8', mode: 0o600 });
  }
}
