import { randomUUID } from 'node:crypto';
import type { CommandTarget, DonationEvent, ResolvedAction, SignedCommand } from './domain.ts';
import { sign } from './security.ts';

export function buildCommand(secret: string, event: DonationEvent, action: ResolvedAction, target: CommandTarget): SignedCommand {
  const unsigned = {
    protocolVersion: 1 as const,
    requestId: randomUUID(),
    timestamp: Date.now(),
    action: action.type,
    target,
    parameters: action.parameters,
    source: {
      eventId: event.eventId,
      ruleId: action.ruleId,
      eventType: event.eventType,
      viewerName: event.viewer.nickname,
      amount: event.amount,
    },
  };
  return { ...unsigned, signature: sign(secret, unsigned) };
}
