import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import type { BridgeConfig, RulesDocument } from './domain.ts';

function assertRecord(value: unknown, name: string): asserts value is Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`${name} must be a JSON object.`);
  }
}

function nonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

function validateStreamers(config: BridgeConfig): void {
  if (config.streamers === undefined) return;
  if (!Array.isArray(config.streamers)) throw new Error('streamers must be an array.');

  const ids = new Set<string>();
  const channels = new Set<string>();
  const players = new Set<string>();
  for (const [index, streamer] of config.streamers.entries()) {
    const label = `streamers[${index}]`;
    if (!streamer || !nonEmptyString(streamer.id) || !nonEmptyString(streamer.displayName)
      || !nonEmptyString(streamer.channelId) || !nonEmptyString(streamer.playerUid) || !nonEmptyString(streamer.tokenStoreFile)) {
      throw new Error(`${label} requires id, displayName, channelId, playerUid, and tokenStoreFile.`);
    }
    if (ids.has(streamer.id)) throw new Error(`${label}.id must be unique.`);
    if (channels.has(streamer.channelId)) throw new Error(`${label}.channelId must be unique.`);
    if (players.has(streamer.playerUid)) throw new Error(`${label}.playerUid must be unique.`);
    ids.add(streamer.id);
    channels.add(streamer.channelId);
    players.add(streamer.playerUid);
  }
}

export async function loadConfig(configPath: string): Promise<{ config: BridgeConfig; baseDirectory: string }> {
  const parsed: unknown = JSON.parse(await readFile(configPath, 'utf8'));
  assertRecord(parsed, 'Config');
  const config = parsed as BridgeConfig;
  if (!config.bridge?.host || !Number.isInteger(config.bridge.port) || config.bridge.port < 1 || config.bridge.port > 65535) {
    throw new Error('Config bridge.host and bridge.port must be valid.');
  }
  if (!config.bridge.secretEnvironmentName || !config.rulesFile || config.matchingMode !== 'first') {
    throw new Error('Config secretEnvironmentName, rulesFile, and matchingMode=first are required.');
  }
  validateStreamers(config);
  if (config.chzzk) {
    const chzzk = config.chzzk;
    if (typeof chzzk.enabled !== 'boolean' || !nonEmptyString(chzzk.clientIdEnvironmentName)
      || !nonEmptyString(chzzk.clientSecretEnvironmentName) || !nonEmptyString(chzzk.redirectUri)) {
      throw new Error('CHZZK configuration is incomplete. Check the example config.');
    }
    if (chzzk.enabled && (!config.streamers?.length) && (!nonEmptyString(chzzk.channelId) || !nonEmptyString(chzzk.tokenStoreFile))) {
      throw new Error('CHZZK live mode needs streamers[] or the legacy chzzk.channelId and chzzk.tokenStoreFile values.');
    }
  } else if (config.streamers?.length) {
    throw new Error('streamers requires the chzzk configuration block for OAuth settings.');
  }
  return { config, baseDirectory: dirname(resolve(configPath)) };
}

export async function loadRules(baseDirectory: string, rulesFile: string): Promise<RulesDocument> {
  const parsed: unknown = JSON.parse(await readFile(resolve(baseDirectory, rulesFile), 'utf8'));
  assertRecord(parsed, 'Rules');
  if (!Array.isArray(parsed.rules)) throw new Error('Rules must contain a rules array.');
  return parsed as RulesDocument;
}
