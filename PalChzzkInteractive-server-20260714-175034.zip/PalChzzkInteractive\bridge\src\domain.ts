export type EventType = 'DONATION' | 'ADMIN_TEST';

export type AmountCondition =
  | { mode: 'exact'; value: number }
  | { mode: 'minimum'; minimum: number }
  | { mode: 'range'; minimum: number; maximum: number };

export type MessageCondition =
  | { mode: 'exact'; value: string }
  | { mode: 'contains'; value: string };

export type ActionType =
  | 'ANNOUNCE'
  | 'SPAWN_ENEMY'
  | 'QUERY_PLAYER_STATUS'
  | 'GIVE_RANDOM_FOOD'
  | 'APPLY_RANDOM_STATUS'
  | 'GIVE_HIGH_TIER_PAL_EGG'
  | 'TOUR_TELEPORT_ALL'
  | 'RANDOM_SAFE_TELEPORT'
  | 'KILL_TARGET'
  | 'SEQUENCE';

export interface Action {
  type: ActionType;
  parameters: Record<string, unknown>;
}

export interface DonationRule {
  id: string;
  name: string;
  enabled: boolean;
  priority: number;
  trigger: {
    eventType: EventType;
    amount: AmountCondition;
    message?: MessageCondition;
  };
  action: Action;
}

export interface RulesDocument {
  rules: DonationRule[];
}

export interface DonationEvent {
  eventId: string;
  eventType: EventType;
  receivedAt: string;
  channelId?: string;
  viewer: {
    id?: string;
    nickname: string;
    anonymous: boolean;
  };
  amount: number;
  message: string;
}

export interface ResolvedAction extends Action {
  ruleId: string;
}

export interface BridgeConfig {
  bridge: {
    host: string;
    port: number;
    secretEnvironmentName: string;
  };
  rulesFile: string;
  matchingMode: 'first';
  limits: {
    maximumSpawnPerAction: number;
    maximumQueueSize: number;
  };
  safety: {
    safeMode: boolean;
    emergencyStop: boolean;
  };
  chzzk?: {
    enabled: boolean;
    clientIdEnvironmentName: string;
    clientSecretEnvironmentName: string;
    redirectUri: string;
    // Legacy single-streamer fallback. New configurations use streamers[] instead.
    channelId?: string;
    tokenStoreFile?: string;
  };
  streamers?: StreamerConfig[];
}

export interface StreamerConfig {
  id: string;
  displayName: string;
  channelId: string;
  playerUid: string;
  tokenStoreFile: string;
}

export type CommandTarget =
  | { type: 'BROADCASTER'; value: string }
  | { type: 'PLAYER_UID'; value: string; streamerId: string };

export interface SignedCommand {
  protocolVersion: 1;
  requestId: string;
  timestamp: number;
  action: ActionType;
  target: CommandTarget;
  parameters: Record<string, unknown>;
  source: {
    eventId: string;
    ruleId: string;
    eventType: EventType;
    viewerName: string;
    amount: number;
  };
  signature: string;
}

export interface CommandResult {
  requestId: string;
  success: boolean;
  resultCode: string;
  message: string;
  data?: Record<string, unknown>;
}
