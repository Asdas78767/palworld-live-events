import { resolve } from 'node:path';
import { loadConfig, loadRules } from './config.ts';
import { LocalModClient } from './mod-client.ts';
import { DonationRuleEngine } from './rule-engine.ts';
import { PalChzzkBridge } from './bridge.ts';
import { ChzzkDonationSession } from './chzzk-session.ts';
import { getChzzkSubscriptions } from './streamer-routing.ts';

function argumentValue(name: string): string | undefined {
  const index = process.argv.indexOf(name);
  return index === -1 ? undefined : process.argv[index + 1];
}

const configPath = resolve(argumentValue('--config') ?? 'config.local.json');
const { config, baseDirectory } = await loadConfig(configPath);
const secret = process.env[config.bridge.secretEnvironmentName];
if (!secret || secret.length < 24) {
  throw new Error(`Set ${config.bridge.secretEnvironmentName} to a random value of at least 24 characters before starting the bridge.`);
}

const rules = await loadRules(baseDirectory, config.rulesFile);
const bridge = new PalChzzkBridge(
  config,
  secret,
  new DonationRuleEngine(rules),
  new LocalModClient(config.bridge.host, config.bridge.port, secret),
);

console.log(`PalChzzk Bridge 0.1.0 ready. ${rules.rules.length} rules loaded.`);
console.log(`Waiting for the Palworld mod at ${config.bridge.host}:${config.bridge.port}.`);
const chzzkSessions: ChzzkDonationSession[] = [];
if (config.chzzk?.enabled) {
  const subscriptions = getChzzkSubscriptions(config);
  if (subscriptions.length === 0) {
    throw new Error('CHZZK live mode requires a legacy chzzk.channelId/tokenStoreFile pair or at least one streamers entry.');
  }
  for (const subscription of subscriptions) {
    const session = new ChzzkDonationSession(config, subscription, baseDirectory, async (donation) => {
      const result = await bridge.processDonation(donation);
      console.log(`[${subscription.id} donation ${donation.eventId}] ${result.status}${'ruleId' in result ? ` (${result.ruleId})` : ''}`);
    });
    chzzkSessions.push(session);
    await session.start();
  }
  console.log(`CHZZK live mode started for ${chzzkSessions.length} streamer(s).`);
} else {
  console.log('CHZZK live mode is disabled. Set chzzk.enabled=true after completing npm run login.');
}

function shutdown(): void {
  for (const session of chzzkSessions) session.stop();
  bridge.close();
  console.log('PalChzzk Bridge stopped.');
  process.exit(0);
}

process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);

void bridge;
