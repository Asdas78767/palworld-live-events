import { randomBytes } from 'node:crypto';
import { createServer, type Server, type Socket } from 'node:net';
import type { CommandResult, SignedCommand } from './domain.ts';
import { verifySignature } from './security.ts';

const allowedActions = new Set(['ANNOUNCE', 'SPAWN_ENEMY', 'QUERY_PLAYER_STATUS']);

function send(socket: Socket, message: Record<string, unknown>): void {
  socket.write(`${JSON.stringify(message)}\n`);
}

export class MockPalworldModServer {
  private readonly secret: string;
  private readonly server: Server;
  private readonly seenRequestIds = new Set<string>();

  constructor(secret: string) {
    this.secret = secret;
    this.server = createServer((socket) => this.handleConnection(socket));
  }

  async listen(port = 0, host = '127.0.0.1'): Promise<number> {
    await new Promise<void>((resolve, reject) => {
      this.server.once('error', reject);
      this.server.listen(port, host, () => resolve());
    });
    const address = this.server.address();
    if (!address || typeof address === 'string') throw new Error('Mock server did not receive a TCP port.');
    return address.port;
  }

  async close(): Promise<void> {
    await new Promise<void>((resolve) => this.server.close(() => resolve()));
  }

  private handleConnection(socket: Socket): void {
    const nonce = randomBytes(24).toString('hex');
    let authenticated = false;
    let buffer = '';
    send(socket, { type: 'challenge', nonce });

    socket.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';
      for (const line of lines) {
        if (!line.trim()) continue;
        const message = JSON.parse(line) as Record<string, unknown>;
        if (message.type === 'auth') {
          authenticated = typeof message.signature === 'string' && verifySignature(this.secret, { nonce }, message.signature);
          send(socket, { type: 'auth_result', success: authenticated, message: authenticated ? undefined : 'Invalid bridge signature.' });
          if (!authenticated) socket.end();
          continue;
        }
        if (message.type === 'command' && authenticated) {
          const result = this.execute(message.command as SignedCommand);
          send(socket, { type: 'command_result', result });
        }
      }
    });
  }

  private execute(command: SignedCommand): CommandResult {
    const { signature, ...unsigned } = command;
    if (!verifySignature(this.secret, unsigned, signature)) {
      return { requestId: command.requestId, success: false, resultCode: 'INVALID_SIGNATURE', message: 'Command signature was rejected.' };
    }
    if (Math.abs(Date.now() - command.timestamp) > 30_000) {
      return { requestId: command.requestId, success: false, resultCode: 'REQUEST_EXPIRED', message: 'Command timestamp is outside the permitted window.' };
    }
    if (this.seenRequestIds.has(command.requestId)) {
      return { requestId: command.requestId, success: false, resultCode: 'DUPLICATE_REQUEST', message: 'Command was already processed.' };
    }
    this.seenRequestIds.add(command.requestId);
    if (!allowedActions.has(command.action)) {
      return { requestId: command.requestId, success: false, resultCode: 'ACTION_DISABLED', message: `${command.action} is not in the initial allow list.` };
    }

    const resultData = command.action === 'SPAWN_ENEMY'
      ? { executedCount: Number(command.parameters.count), simulated: true }
      : { simulated: true };
    return { requestId: command.requestId, success: true, resultCode: 'OK', message: `${command.action} accepted by mock mod.`, data: resultData };
  }
}
