import { createConnection, type Socket } from 'node:net';
import type { CommandResult, SignedCommand } from './domain.ts';
import { sign } from './security.ts';

type WireMessage =
  | { type: 'challenge'; nonce: string }
  | { type: 'auth'; signature: string }
  | { type: 'auth_result'; success: boolean; message?: string }
  | { type: 'command'; command: SignedCommand }
  | { type: 'command_result'; result: CommandResult };

function writeLine(socket: Socket, message: WireMessage | Record<string, unknown>): void {
  socket.write(`${JSON.stringify(message)}\n`);
}

export class LocalModClient {
  private readonly host: string;
  private readonly port: number;
  private readonly secret: string;
  private socket?: Socket;
  private authenticated = false;
  private connectPromise?: Promise<void>;
  private readonly pending = new Map<string, { resolve: (value: CommandResult) => void; reject: (reason: Error) => void }>();

  constructor(
    host: string,
    port: number,
    secret: string,
  ) {
    this.host = host;
    this.port = port;
    this.secret = secret;
  }

  async send(command: SignedCommand): Promise<CommandResult> {
    await this.connect();
    return new Promise<CommandResult>((resolve, reject) => {
      this.pending.set(command.requestId, { resolve, reject });
      writeLine(this.socket!, { type: 'command', command });
      setTimeout(() => {
        const pending = this.pending.get(command.requestId);
        if (pending) {
          this.pending.delete(command.requestId);
          pending.reject(new Error(`Timed out waiting for Palworld mod response: ${command.requestId}`));
        }
      }, 10_000).unref();
    });
  }

  close(): void {
    this.socket?.destroy();
    this.socket = undefined;
    this.authenticated = false;
  }

  private connect(): Promise<void> {
    if (this.authenticated) return Promise.resolve();
    if (this.connectPromise) return this.connectPromise;

    this.connectPromise = new Promise<void>((resolve, reject) => {
      const socket = createConnection({ host: this.host, port: this.port });
      this.socket = socket;
      let buffer = '';
      const timeout = setTimeout(() => reject(new Error('Timed out waiting for Palworld mod authentication.')), 10_000);

      socket.on('data', (chunk) => {
        buffer += chunk.toString('utf8');
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          if (!line.trim()) continue;
          this.handleMessage(JSON.parse(line) as WireMessage, resolve, reject, timeout);
        }
      });
      socket.once('error', (error) => reject(error));
      socket.once('close', () => {
        this.authenticated = false;
        this.connectPromise = undefined;
      });
    });

    return this.connectPromise;
  }

  private handleMessage(
    message: WireMessage,
    resolveConnection: () => void,
    rejectConnection: (reason: Error) => void,
    timeout: NodeJS.Timeout,
  ): void {
    if (message.type === 'challenge') {
      writeLine(this.socket!, { type: 'auth', signature: sign(this.secret, { nonce: message.nonce }) });
      return;
    }
    if (message.type === 'auth_result') {
      clearTimeout(timeout);
      if (!message.success) {
        rejectConnection(new Error(message.message ?? 'Palworld mod rejected authentication.'));
        return;
      }
      this.authenticated = true;
      resolveConnection();
      return;
    }
    if (message.type === 'command_result') {
      const pending = this.pending.get(message.result.requestId);
      if (pending) {
        this.pending.delete(message.result.requestId);
        pending.resolve(message.result);
      }
    }
  }
}
