import type { DonationEvent, DonationRule, ResolvedAction, RulesDocument } from './domain.ts';

function normalizedMessage(message: string): string {
  return message.trim().replace(/\s+/g, ' ').toLocaleLowerCase('ko-KR');
}

function amountMatches(amount: number, rule: DonationRule): boolean {
  const condition = rule.trigger.amount;
  if (condition.mode === 'exact') return amount === condition.value;
  if (condition.mode === 'minimum') return amount >= condition.minimum;
  return amount >= condition.minimum && amount <= condition.maximum;
}

function messageMatches(event: DonationEvent, rule: DonationRule): boolean {
  const condition = rule.trigger.message;
  if (!condition) return true;

  const message = normalizedMessage(event.message);
  const expected = normalizedMessage(condition.value);
  return condition.mode === 'exact' ? message === expected : message.includes(expected);
}

function interpolate(value: unknown, event: DonationEvent): unknown {
  if (typeof value === 'string') {
    return value
      .replaceAll('{viewer}', event.viewer.nickname)
      .replaceAll('{amount}', String(event.amount))
      .replaceAll('{message}', event.message.trim());
  }
  if (Array.isArray(value)) return value.map((item) => interpolate(item, event));
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, interpolate(item, event)]));
  }
  return value;
}

export class DonationRuleEngine {
  readonly rules: DonationRule[];

  constructor(document: RulesDocument) {
    this.rules = document.rules.map((rule, sourceOrder) => ({ ...rule, sourceOrder } as DonationRule & { sourceOrder: number }))
      .sort((left, right) => right.priority - left.priority || (left as any).sourceOrder - (right as any).sourceOrder);
  }

  match(event: DonationEvent): ResolvedAction | undefined {
    const rule = this.rules.find((candidate) =>
      candidate.enabled &&
      candidate.trigger.eventType === event.eventType &&
      amountMatches(event.amount, candidate) &&
      messageMatches(event, candidate),
    );

    if (!rule) return undefined;
    return {
      ruleId: rule.id,
      type: rule.action.type,
      parameters: interpolate(rule.action.parameters, event) as Record<string, unknown>,
    };
  }
}
