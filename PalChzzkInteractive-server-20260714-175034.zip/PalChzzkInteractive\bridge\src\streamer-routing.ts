import type { BridgeConfig, CommandTarget, DonationEvent, StreamerConfig } from './domain.ts';

export interface ChzzkSubscription {
  id: string;
  displayName: string;
  channelId: string;
  tokenStoreFile: string;
}

export type TargetResolution =
  | { success: true; target: CommandTarget }
  | { success: false; reason: string };

export function getChzzkSubscriptions(config: BridgeConfig): ChzzkSubscription[] {
  if (config.streamers?.length) {
    return config.streamers.map(({ id, displayName, channelId, tokenStoreFile }) => ({ id, displayName, channelId, tokenStoreFile }));
  }
  const legacy = config.chzzk;
  if (legacy?.channelId && legacy.tokenStoreFile) {
    return [{ id: 'default', displayName: '기본 스트리머', channelId: legacy.channelId, tokenStoreFile: legacy.tokenStoreFile }];
  }
  return [];
}

export function selectChzzkSubscription(config: BridgeConfig, streamerId?: string): ChzzkSubscription {
  const subscriptions = getChzzkSubscriptions(config);
  if (subscriptions.length === 0) throw new Error('Add at least one streamer with channelId and tokenStoreFile to the configuration.');
  if (streamerId) {
    const selected = subscriptions.find((streamer) => streamer.id === streamerId);
    if (!selected) throw new Error(`No streamer with id '${streamerId}' exists in the configuration.`);
    return selected;
  }
  if (subscriptions.length === 1) return subscriptions[0];
  throw new Error('Multiple streamers are configured. Pass --streamer <id> when logging in.');
}

export function resolveDonationTarget(config: BridgeConfig, event: DonationEvent): TargetResolution {
  const streamers: StreamerConfig[] = config.streamers ?? [];
  if (streamers.length === 0) {
    return { success: true, target: { type: 'BROADCASTER', value: 'configured-broadcaster' } };
  }
  if (!event.channelId) return { success: false, reason: 'Donation did not include a CHZZK channel ID.' };
  const streamer = streamers.find((candidate) => candidate.channelId === event.channelId);
  if (!streamer) return { success: false, reason: `No Palworld player mapping exists for CHZZK channel ${event.channelId}.` };
  return { success: true, target: { type: 'PLAYER_UID', value: streamer.playerUid, streamerId: streamer.id } };
}
