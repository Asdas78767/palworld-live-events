import assert from 'node:assert/strict';
import test from 'node:test';
import { makeAdminDonation } from '../src/admin-event.ts';
import { PalChzzkBridge } from '../src/bridge.ts';
import type { BridgeConfig, RulesDocument } from '../src/domain.ts';
import { LocalModClient } from '../src/mod-client.ts';
import { MockPalworldModServer } from '../src/mock-mod-server.ts';
import { DonationRuleEngine } from '../src/rule-engine.ts';

test('a signed donation command reaches the local mod and returns a result', async () => {
  const secret = 'development-secret-0123456789';
  const mock = new MockPalworldModServer(secret);
  const port = await mock.listen();
  const config: BridgeConfig = {
    bridge: { host: '127.0.0.1', port, secretEnvironmentName: 'PALCHZZK_BRIDGE_SECRET' },
    rulesFile: 'unused.json',
    matchingMode: 'first',
    limits: { maximumSpawnPerAction: 20, maximumQueueSize: 100 },
    safety: { safeMode: false, emergencyStop: false },
  };
  const rules: RulesDocument = {
    rules: [
      { id: 'spawn-three', name: 'spawn', enabled: true, priority: 1, trigger: { eventType: 'DONATION', amount: { mode: 'range', minimum: 3000, maximum: 4999 } }, action: { type: 'SPAWN_ENEMY', parameters: { pool: 'basic_enemy', count: 3 } } },
    ],
  };
  const bridge = new PalChzzkBridge(config, secret, new DonationRuleEngine(rules), new LocalModClient(config.bridge.host, port, secret));

  try {
    const result = await bridge.processDonation(makeAdminDonation(3000, '불'));
    assert.equal(result.status, 'EXECUTED');
    assert.equal(result.result.success, true);
    assert.equal(result.result.data?.executedCount, 3);
  }
  finally {
    bridge.close();
    await mock.close();
  }
});

test('safe mode refuses game-changing commands before they reach the mod', async () => {
  const secret = 'development-secret-0123456789';
  const config: BridgeConfig = {
    bridge: { host: '127.0.0.1', port: 1, secretEnvironmentName: 'PALCHZZK_BRIDGE_SECRET' },
    rulesFile: 'unused.json',
    matchingMode: 'first',
    limits: { maximumSpawnPerAction: 20, maximumQueueSize: 100 },
    safety: { safeMode: true, emergencyStop: false },
  };
  const rules: RulesDocument = {
    rules: [
      { id: 'spawn', name: 'spawn', enabled: true, priority: 1, trigger: { eventType: 'DONATION', amount: { mode: 'minimum', minimum: 1 } }, action: { type: 'SPAWN_ENEMY', parameters: { count: 1 } } },
    ],
  };
  const bridge = new PalChzzkBridge(config, secret, new DonationRuleEngine(rules), new LocalModClient('127.0.0.1', 1, secret));
  const result = await bridge.processDonation(makeAdminDonation(1000));
  assert.deepEqual(result, { status: 'BLOCKED', reason: 'Safe mode blocks SPAWN_ENEMY.' });
});
