import assert from 'node:assert/strict';
import test from 'node:test';
import { buildChzzkSocketUrl, normalizeChzzkDonation, parseEnginePacket } from '../src/chzzk-protocol.ts';

test('session URL becomes an Engine.IO v3 WebSocket URL without dropping auth', () => {
  const url = new URL(buildChzzkSocketUrl('https://ssio.example.test:443?auth=temporary-token'));
  assert.equal(url.protocol, 'wss:');
  assert.equal(url.pathname, '/socket.io/');
  assert.equal(url.searchParams.get('auth'), 'temporary-token');
  assert.equal(url.searchParams.get('EIO'), '3');
  assert.equal(url.searchParams.get('transport'), 'websocket');
});

test('Socket.IO system and donation messages are parsed safely', () => {
  assert.deepEqual(parseEnginePacket('2'), { kind: 'PING' });
  assert.deepEqual(parseEnginePacket('42["SYSTEM",{"type":"connected","data":{"sessionKey":"session-1"}}]'), {
    kind: 'EVENT',
    eventName: 'SYSTEM',
    data: { type: 'connected', data: { sessionKey: 'session-1' } },
  });
});

test('CHZZK donation payload becomes the bridge donation shape', () => {
  const event = normalizeChzzkDonation({
    donationId: 'payment-123',
    channelId: 'streamer-channel-1',
    donatorChannelId: 'viewer-8',
    donatorNickname: '시청자\u0000이름',
    payAmount: '3000',
    donationText: '불\n',
  });
  assert.equal(event?.eventId, 'chzzk-payment-123');
  assert.equal(event?.channelId, 'streamer-channel-1');
  assert.equal(event?.amount, 3000);
  assert.equal(event?.viewer.nickname, '시청자 이름');
  assert.equal(event?.message, '불 ');
  assert.equal(event?.viewer.anonymous, false);
});

test('invalid CHZZK donation amounts cannot enter the rule engine', () => {
  assert.equal(normalizeChzzkDonation({ payAmount: '0' }), undefined);
  assert.equal(normalizeChzzkDonation({ payAmount: 'three thousand' }), undefined);
});
