import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import type { DonationEvent, RulesDocument } from '../src/domain.ts';
import { DonationRuleEngine } from '../src/rule-engine.ts';

const rulesPath = new URL('../../rules.example.json', import.meta.url);
const rules = JSON.parse(await readFile(rulesPath, 'utf8')) as RulesDocument;
const engine = new DonationRuleEngine(rules);

function donation(amount: number): DonationEvent {
  return {
    eventId: `donation-${amount}`,
    eventType: 'DONATION',
    receivedAt: '2026-07-14T00:00:00.000Z',
    viewer: { nickname: '테스터', anonymous: false },
    amount,
    message: '',
  };
}

test('the broadcaster-approved donation amounts resolve to the intended actions', () => {
  assert.equal(engine.match(donation(1000))?.type, 'GIVE_RANDOM_FOOD');
  assert.equal(engine.match(donation(2000))?.type, 'APPLY_RANDOM_STATUS');
  assert.equal(engine.match(donation(3000))?.type, 'SPAWN_ENEMY');
  assert.equal(engine.match(donation(5000))?.type, 'SEQUENCE');
  assert.equal(engine.match(donation(10000))?.type, 'SPAWN_ENEMY');
  assert.equal(engine.match(donation(30000))?.type, 'RANDOM_SAFE_TELEPORT');
  assert.equal(engine.match(donation(50000))?.type, 'KILL_TARGET');
});

test('the five-thousand-won event contains both the egg and player tour actions', () => {
  const action = engine.match(donation(5000));
  const actions = action?.parameters.actions as Array<{ type: string }>;
  assert.deepEqual(actions.map((item) => item.type), ['GIVE_HIGH_TIER_PAL_EGG', 'TOUR_TELEPORT_ALL']);
});
