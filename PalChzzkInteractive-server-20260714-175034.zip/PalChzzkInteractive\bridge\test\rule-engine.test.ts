import assert from 'node:assert/strict';
import test from 'node:test';
import type { DonationEvent, RulesDocument } from '../src/domain.ts';
import { DonationRuleEngine } from '../src/rule-engine.ts';

const event: DonationEvent = {
  eventId: 'test-1',
  eventType: 'DONATION',
  receivedAt: '2026-07-13T00:00:00.000Z',
  viewer: { nickname: '테스터', anonymous: false },
  amount: 7777,
  message: ' 불 ',
};

test('exact amount rule overrides a broader range by priority', () => {
  const rules: RulesDocument = {
    rules: [
      { id: 'range', name: 'range', enabled: true, priority: 100, trigger: { eventType: 'DONATION', amount: { mode: 'range', minimum: 5000, maximum: 9999 } }, action: { type: 'ANNOUNCE', parameters: { message: 'range' } } },
      { id: 'exact', name: 'exact', enabled: true, priority: 1000, trigger: { eventType: 'DONATION', amount: { mode: 'exact', value: 7777 } }, action: { type: 'ANNOUNCE', parameters: { message: '{viewer} {amount}' } } },
    ],
  };
  const result = new DonationRuleEngine(rules).match(event);
  assert.equal(result?.ruleId, 'exact');
  assert.equal(result?.parameters.message, '테스터 7777');
});

test('message conditions are normalized before matching', () => {
  const rules: RulesDocument = {
    rules: [
      { id: 'fire', name: 'fire', enabled: true, priority: 1, trigger: { eventType: 'DONATION', amount: { mode: 'minimum', minimum: 1 }, message: { mode: 'exact', value: '불' } }, action: { type: 'SPAWN_ENEMY', parameters: { pool: 'fire', count: 1 } } },
    ],
  };
  assert.equal(new DonationRuleEngine(rules).match(event)?.ruleId, 'fire');
});
