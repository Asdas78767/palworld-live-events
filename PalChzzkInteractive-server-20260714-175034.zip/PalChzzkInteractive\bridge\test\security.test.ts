import assert from 'node:assert/strict';
import test from 'node:test';
import { canonicalJson, sign, verifySignature } from '../src/security.ts';

test('canonical signatures ignore object key ordering', () => {
  const left = { z: 1, inner: { b: true, a: 'x' } };
  const right = { inner: { a: 'x', b: true }, z: 1 };
  assert.equal(canonicalJson(left), canonicalJson(right));
  assert.equal(sign('development-secret-0123456789', left), sign('development-secret-0123456789', right));
});

test('signature verification rejects changed payloads', () => {
  const secret = 'development-secret-0123456789';
  const signature = sign(secret, { requestId: '1', amount: 3000 });
  assert.equal(verifySignature(secret, { requestId: '1', amount: 3000 }, signature), true);
  assert.equal(verifySignature(secret, { requestId: '1', amount: 5000 }, signature), false);
});
