import assert from 'node:assert/strict';
import test from 'node:test';
import type { BridgeConfig, DonationEvent } from '../src/domain.ts';
import { getChzzkSubscriptions, resolveDonationTarget, selectChzzkSubscription } from '../src/streamer-routing.ts';

const config: BridgeConfig = {
  bridge: { host: '127.0.0.1', port: 18472, secretEnvironmentName: 'PALCHZZK_BRIDGE_SECRET' },
  rulesFile: 'rules.example.json',
  matchingMode: 'first',
  limits: { maximumSpawnPerAction: 20, maximumQueueSize: 100 },
  safety: { safeMode: false, emergencyStop: false },
  chzzk: {
    enabled: true,
    clientIdEnvironmentName: 'PALCHZZK_CLIENT_ID',
    clientSecretEnvironmentName: 'PALCHZZK_CLIENT_SECRET',
    redirectUri: 'http://127.0.0.1:18473/callback',
  },
  streamers: [
    { id: 'tosuni', displayName: '토순이', channelId: 'channel-tosuni', playerUid: 'player-tosuni', tokenStoreFile: '.local/chzzk-tosuni.json' },
    { id: 'mango', displayName: '망고', channelId: 'channel-mango', playerUid: 'player-mango', tokenStoreFile: '.local/chzzk-mango.json' },
  ],
};

function donation(channelId?: string): DonationEvent {
  return {
    eventId: 'event-1', eventType: 'DONATION', receivedAt: '2026-07-14T00:00:00.000Z', channelId,
    viewer: { nickname: 'viewer', anonymous: false }, amount: 1000, message: '',
  };
}

test('each configured channel maps only to its own Palworld player UID', () => {
  assert.deepEqual(resolveDonationTarget(config, donation('channel-tosuni')), {
    success: true, target: { type: 'PLAYER_UID', value: 'player-tosuni', streamerId: 'tosuni' },
  });
  assert.deepEqual(resolveDonationTarget(config, donation('channel-mango')), {
    success: true, target: { type: 'PLAYER_UID', value: 'player-mango', streamerId: 'mango' },
  });
});

test('a missing or unconfigured channel is blocked before any game command is sent', () => {
  assert.equal(resolveDonationTarget(config, donation()).success, false);
  assert.equal(resolveDonationTarget(config, donation('unknown-channel')).success, false);
});

test('each streamer has a separate CHZZK subscription and login selector', () => {
  assert.deepEqual(getChzzkSubscriptions(config).map((streamer) => streamer.id), ['tosuni', 'mango']);
  assert.equal(selectChzzkSubscription(config, 'mango').tokenStoreFile, '.local/chzzk-mango.json');
  assert.throws(() => selectChzzkSubscription(config), /Multiple streamers/);
});
