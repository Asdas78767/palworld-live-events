# Copy this file to .local\chzzk.env.ps1 before running the bridge.
# Do not share the copied local file or include it in a distribution ZIP.

$env:PALCHZZK_CLIENT_ID = 'PASTE_CLIENT_ID_HERE'
$env:PALCHZZK_CLIENT_SECRET = 'PASTE_CLIENT_SECRET_HERE'
$env:PALCHZZK_BRIDGE_SECRET = 'replace-this-with-a-random-string-of-at-least-24-characters'
