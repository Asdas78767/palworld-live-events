# 치지직 연결 방법

## 준비

치지직 개발자 센터에서 앱을 만든다. 앱 ID와 이름에는 `chzzk`, `치지직`, `naver`, `네이버`를 넣지 않는다. 예를 들어 `PalStream Interactive`를 사용한다.

로그인 Redirect URI는 아래 값과 **완전히 동일하게** 등록한다.

```text
http://127.0.0.1:18473/callback
```

앱은 방송인 본인의 계정으로 승인해야 한다. 치지직 세션 API는 해당 Access Token을 발급받은 사용자 이벤트만 구독한다.

## 로컬 설정

```powershell
Set-Location 'C:\Users\Mingy\OneDrive\Desktop\PalworldModdingKit-62fad4130238cb0aadf024b87496e7387d5f4bf5\PalChzzkInteractive'
Copy-Item config.example.json config.local.json
[Environment]::SetEnvironmentVariable('PALCHZZK_CLIENT_ID', '개발자센터의_Client_ID', 'User')
[Environment]::SetEnvironmentVariable('PALCHZZK_CLIENT_SECRET', '개발자센터의_Client_Secret', 'User')
[Environment]::SetEnvironmentVariable('PALCHZZK_BRIDGE_SECRET', '24자_이상의_무작위_로컬_비밀값', 'User')
```

환경 변수를 설정했다면 새 PowerShell 창을 열어야 한다. `config.local.json`에 방송 채널 ID를 채우고 `chzzk.enabled`는 로그인 전까지 `false`로 둔다.

## 로그인과 실행

```powershell
npm run login
```

표시된 주소를 방송인 브라우저에서 열어 권한을 승인한다. 성공하면 토큰은 `.local/chzzk-token.json`에만 저장된다. 이 파일은 Git에서 제외되며 공유하거나 배포하면 안 된다.

그 뒤 `config.local.json`의 `chzzk.enabled`를 `true`로 바꿔 실행한다.

```powershell
npm start
```

브리지는 치지직의 후원 세션을 구독하고, 후원 금액을 규칙에 대입한 뒤 HMAC 서명된 허용 명령만 `127.0.0.1:18472`의 팰월드 모드로 보낸다.

## 아직 연결하면 안 되는 상태

현재 `mod/ue4ss`는 UE4SS 로더와 프로토콜 검증용이다. 실제 팰월드 전용 서버에서 `ANNOUNCE`와 `SPAWN_ENEMY`를 실행하는 네이티브 어댑터가 설치되기 전에는 치지직 실방송 연결을 켜지 않는다. 대신 `npm run mock-mod`와 `npm run test:donation`으로 전체 통신을 검증한다.
