# 여러 스트리머 동시 연동

`streamers`에는 **치지직 채널 하나와 팰월드 플레이어 한 명**을 한 쌍으로 등록합니다. 후원 이벤트에 들어온 채널 ID가 정확히 일치할 때만 해당 `playerUid`를 명령 대상으로 사용합니다. 채널 ID가 없거나 등록되지 않은 이벤트는 게임 명령을 보내지 않고 차단합니다.

## 설정 예시

`config.example.json`을 복사해 만든 `config.local.json`에 다음처럼 넣습니다. `config.local.json`과 `.local` 토큰 파일은 Git에 포함되지 않습니다.

```json
{
  "chzzk": {
    "enabled": false,
    "clientIdEnvironmentName": "PALCHZZK_CLIENT_ID",
    "clientSecretEnvironmentName": "PALCHZZK_CLIENT_SECRET",
    "redirectUri": "http://127.0.0.1:18473/callback"
  },
  "streamers": [
    {
      "id": "tosuni",
      "displayName": "토순이",
      "channelId": "치지직_토순이_채널_ID",
      "playerUid": "DA0570DE000000000000000000000000",
      "tokenStoreFile": ".local/chzzk-tosuni-token.json"
    },
    {
      "id": "second-streamer",
      "displayName": "두번째 스트리머",
      "channelId": "치지직_두번째_채널_ID",
      "playerUid": "전용_서버_로그에_표시되는_Player_ID",
      "tokenStoreFile": ".local/chzzk-second-streamer-token.json"
    }
  ]
}
```

- `id`, `channelId`, `playerUid`는 각각 중복될 수 없습니다.
- `playerUid`는 전용 서버 콘솔의 `Player id:` 값입니다. Steam ID가 아닙니다.
- 같은 치지직 개발자 앱의 `CLIENT_ID`와 `CLIENT_SECRET`을 공유해도 되지만, 로그인 토큰은 스트리머마다 별도 파일에 저장됩니다.

## 스트리머별 로그인

PowerShell에서 환경 변수를 설정한 뒤, 스트리머가 자신의 치지직 계정으로 각각 한 번씩 로그인합니다. 로컬 콜백 포트 하나를 공유하므로 로그인은 **동시에 하지 말고 순서대로** 실행합니다.

```powershell
Set-Location 'C:\Users\Mingy\OneDrive\Desktop\PalworldModdingKit-62fad4130238cb0aadf024b87496e7387d5f4bf5\PalChzzkInteractive'
$env:PALCHZZK_CLIENT_ID = '개발자센터_Client_ID'
$env:PALCHZZK_CLIENT_SECRET = '개발자센터_Client_Secret'

npm run login -- --streamer tosuni
npm run login -- --streamer second-streamer
```

두 로그인 모두 끝난 다음 `chzzk.enabled`를 `true`로 바꾸고 `npm start`를 실행합니다. 브리지는 채널별 세션을 열고, 각 후원을 그 채널에 매핑한 플레이어에게만 전달합니다.

> 현재 UE4SS 런타임 연결은 공지 기능을 확인한 단계입니다. 이 문서의 플레이어 대상 분기는 브리지와 서명 명령에 구현되어 있으며, 다음 UE4SS 명령 어댑터가 대상 Player UID를 사용하게 됩니다.
