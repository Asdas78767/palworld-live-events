# 0.1 아키텍처

`PalChzzkInteractive`는 치지직 인증·이벤트 처리를 게임 서버에서 분리한다. 치지직 토큰은 브리지 프로세스에만 존재하고, 게임 모드는 서명된 허용 명령만 받는다.

```text
CHZZK Open API
       │ OAuth / Session / Donation event
       ▼
TypeScript Bridge
       │ rule matching / HMAC / audit boundary
       ▼
127.0.0.1 TCP JSON Lines
       │ challenge-response / signed command
       ▼
UE4SS native server adapter
       │ game-thread queue
       ▼
Palworld dedicated server
```

## 치지직 경계

`npm run login`은 로컬 루프백 주소에서만 OAuth 콜백을 받고, 토큰을 `.local/chzzk-token.json`에 저장한다. 브리지는 만료 전 토큰을 갱신하고, 사용자 인증 세션을 만든 뒤 후원 이벤트를 구독한다.

세션 서버가 지원하는 Socket.IO 2 / Engine.IO 3 통신은 Node.js 내장 WebSocket으로 최소한만 처리한다. 지원하는 패킷은 연결, ping/pong, 기본 네임스페이스 연결, `SYSTEM`, `DONATION`이다. 외부의 오래된 Socket.IO 클라이언트 의존성은 추가하지 않는다.

치지직 문서에 공개된 후원 본문에는 안정적인 후원 이벤트 ID가 명시되지 않아, ID가 전달될 때만 중복 식별에 사용한다. ID가 없을 때는 동일한 금액·메시지의 정상 후원을 잘못 합치지 않도록 각각 별도 이벤트로 처리한다.

## 명령 안전성

브리지는 게임 함수명, 콘솔 명령, 파일 경로를 전달하지 않는다. 0.1 허용 목록은 다음 세 개다.

```text
ANNOUNCE
SPAWN_ENEMY
QUERY_PLAYER_STATUS
```

모드 측은 다음을 모두 검사해야 한다.

- 일회용 난수 기반 브리지 인증
- HMAC-SHA256 서명
- 30초 이내의 요청 시각
- 중복 `requestId` 거부
- 허용 목록
- 생성 수 제한
- 게임 스레드 대기열
- 안전 모드와 긴급 정지

초기 구현은 외부 의존성을 줄이기 위해 WebSocket 대신 **로컬 TCP JSON Lines**를 사용한다. 주소는 `127.0.0.1`로만 바인딩하며 외부 연결은 허용하지 않는다. 정식 UE4SS C++ 모드가 준비되더라도 HMAC 서명과 이 검증 절차는 유지한다.

## 현재 한계

브리지는 실제 치지직 세션을 받을 준비가 되어 있지만, `mod/ue4ss`의 Lua는 현재 로더 확인용이다. 실제 `ANNOUNCE` 또는 `SPAWN_ENEMY`를 실행하는 네이티브 UE4SS 어댑터는 대상 팰월드 전용 서버 버전에서 클래스·함수·게임 스레드 호출을 확인한 뒤에만 작성한다. 검증 전에는 실방송 연결 대신 모의 모드로 테스트한다.
