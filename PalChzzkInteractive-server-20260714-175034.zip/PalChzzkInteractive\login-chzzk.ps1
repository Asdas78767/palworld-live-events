[CmdletBinding()]
param(
  [string]$StreamerId = 'tosuni'
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '.local\chzzk.env.ps1')
if ($env:PALCHZZK_CLIENT_SECRET -eq 'PASTE_CLIENT_SECRET_HERE') {
  throw 'Open .local\chzzk.env.ps1 and paste the Client Secret before continuing.'
}
Push-Location $PSScriptRoot
try {
  npm run login -- --streamer $StreamerId
} finally {
  Pop-Location
}
