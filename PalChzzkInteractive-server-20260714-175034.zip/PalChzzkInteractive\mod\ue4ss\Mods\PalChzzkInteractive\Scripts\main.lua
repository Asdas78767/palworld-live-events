-- PalChzzk Interactive 0.1 dedicated-server probe.
-- This script deliberately exposes only a manual ANNOUNCE test. It has no
-- socket listener and cannot execute a donation-triggered game action yet.

local function find_game_state()
    local game_state = FindFirstOf("PalGameStateInGame")
    if game_state and game_state:IsValid() then
        return game_state
    end
    return nil
end

local function report_announce_capability()
    ExecuteInGameThread(function()
        local game_state = find_game_state()
        if not game_state then
            print("[PalChzzkInteractive] PalGameStateInGame is not ready; announcement test is unavailable.")
            return
        end

        local ok, announce_function = pcall(function()
            return game_state.BroadcastServerNotice
        end)
        if ok and announce_function then
            print("[PalChzzkInteractive] ANNOUNCE probe ready: " .. game_state:GetFullName())
        else
            print("[PalChzzkInteractive] ANNOUNCE probe failed: BroadcastServerNotice was not found.")
        end
    end)
end

RegisterConsoleCommandHandler("palchzzk_announce", function(_, parameters, _)
    if #parameters < 1 then
        print("[PalChzzkInteractive] Usage: palchzzk_announce <message>")
        return true
    end

    local message = table.concat(parameters, " ")
    if #message > 240 then
        print("[PalChzzkInteractive] Announcement rejected: message is longer than 240 characters.")
        return true
    end

    ExecuteInGameThread(function()
        local game_state = find_game_state()
        if not game_state then
            print("[PalChzzkInteractive] Announcement rejected: game state is not ready.")
            return
        end

        local ok, error_message = pcall(function()
            game_state:BroadcastServerNotice(message)
        end)
        if ok then
            print("[PalChzzkInteractive] ANNOUNCE completed.")
        else
            print("[PalChzzkInteractive] ANNOUNCE failed: " .. tostring(error_message))
        end
    end)
    return true
end)

print("[PalChzzkInteractive] loader active; manual ANNOUNCE probe enabled.")
print("[PalChzzkInteractive] use: palchzzk_announce <message>")
ExecuteWithDelay(10000, report_announce_capability)
