# UE4SS 게임 측 어댑터

이 폴더는 UE4SS가 모드를 읽는 구조와 0.1 통신 규약을 제공한다.

`Mods/PalChzzkInteractive/Scripts/main.lua`는 로더 확인과 **수동 공지 시험 명령**만 수행한다. 서버가 준비된 뒤 UE4SS 콘솔에서 `palchzzk_announce <메시지>`를 실행하면 `APalGameStateInGame::BroadcastServerNotice`를 한 번 호출한다. 후원 브리지에서 이 명령을 실행하는 기능은 아직 없다.

실제 브리지의 `ANNOUNCE`와 `SPAWN_ENEMY` 실행기는 현재 팰월드 전용 서버 버전에서 함수·클래스·게임 스레드 호출 경로가 확인된 후 **UE4SS C++ 모드**로 구현한다. 브리지가 준비됐다고 해서 이 Lua 스크립트만으로 적을 소환하지는 않는다.

## 설치 전 확인

1. 전용 서버를 백업한다.
2. UE4SS를 서버의 `Pal\Binaries\Win64`에 설치한다.
3. 이 폴더 안의 `Mods` 내용을 UE4SS의 `Mods` 폴더에 병합한다.
4. 서버를 시작하고 UE4SS 로그에서 `PalChzzkInteractive loader active`를 확인한다.

## C++ 어댑터 완료 조건

- `127.0.0.1:18472`만 수신
- bridge HMAC 인증과 명령 서명 검증
- 요청을 게임 스레드 대기열로 전달
- 플레이어·월드 객체는 실행 직전에 다시 조회
- `SPAWN_ENEMY`는 검증된 팰 ID 목록과 생성 제한만 사용
- 안전 모드·긴급 정지·이벤트 액터 정리 지원
