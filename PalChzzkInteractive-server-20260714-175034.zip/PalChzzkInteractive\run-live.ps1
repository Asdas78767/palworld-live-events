$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '.local\chzzk.env.ps1')
if ($env:PALCHZZK_CLIENT_SECRET -eq 'PASTE_CLIENT_SECRET_HERE') {
  throw 'Open .local\chzzk.env.ps1 and paste the Client Secret before continuing.'
}
if ($env:PALCHZZK_BRIDGE_SECRET -eq 'replace-this-with-a-random-string-of-at-least-24-characters') {
  throw 'Open .local\chzzk.env.ps1 and set PALCHZZK_BRIDGE_SECRET to a random value of at least 24 characters.'
}
Push-Location $PSScriptRoot
try {
  npm start
} finally {
  Pop-Location
}
