[CmdletBinding()]
param(
  [string]$DestinationDirectory = (Join-Path (Split-Path -Parent $PSScriptRoot) 'release')
)

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$bundleName = "PalChzzkInteractive-server-$timestamp"
$bundleDirectory = Join-Path $DestinationDirectory $bundleName
$packageRoot = Join-Path $bundleDirectory 'PalChzzkInteractive'
$zipPath = Join-Path $DestinationDirectory "$bundleName.zip"

$excludedNames = @(
  '.git',
  '.local',
  'config.local.json',
  'data',
  'logs',
  'node_modules',
  'release'
)

New-Item -ItemType Directory -Force -Path $packageRoot | Out-Null

Get-ChildItem -LiteralPath $projectRoot -Force |
  Where-Object { $_.Name -notin $excludedNames } |
  ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $packageRoot -Recurse -Force
  }

Compress-Archive -LiteralPath $packageRoot -DestinationPath $zipPath -CompressionLevel Optimal

Write-Host "Created: $zipPath"
Write-Host 'Excluded: local credentials, OAuth tokens, local config, logs, data, node_modules, and release files.'
