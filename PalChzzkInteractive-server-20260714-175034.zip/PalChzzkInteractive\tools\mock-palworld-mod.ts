import { resolve } from 'node:path';
import { loadConfig } from '../bridge/src/config.ts';
import { MockPalworldModServer } from '../bridge/src/mock-mod-server.ts';

function argumentValue(name: string): string | undefined {
  const index = process.argv.indexOf(name);
  return index === -1 ? undefined : process.argv[index + 1];
}

const configPath = resolve(argumentValue('--config') ?? 'config.local.json');
const { config } = await loadConfig(configPath);
const secret = process.env[config.bridge.secretEnvironmentName];
if (!secret || secret.length < 24) throw new Error(`Set ${config.bridge.secretEnvironmentName} before starting the mock mod.`);

const server = new MockPalworldModServer(secret);
await server.listen(config.bridge.port, config.bridge.host);
console.log(`Mock Palworld mod listening at ${config.bridge.host}:${config.bridge.port}.`);
console.log('This validates the protocol only; it does not modify a game server. Press Ctrl+C to stop.');

process.once('SIGINT', async () => {
  await server.close();
  process.exit(0);
});
