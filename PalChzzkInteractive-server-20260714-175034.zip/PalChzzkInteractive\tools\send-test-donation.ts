import { resolve } from 'node:path';
import { makeAdminDonation } from '../bridge/src/admin-event.ts';
import { PalChzzkBridge } from '../bridge/src/bridge.ts';
import { loadConfig, loadRules } from '../bridge/src/config.ts';
import { LocalModClient } from '../bridge/src/mod-client.ts';
import { DonationRuleEngine } from '../bridge/src/rule-engine.ts';

function argumentValue(name: string): string | undefined {
  const index = process.argv.indexOf(name);
  return index === -1 ? undefined : process.argv[index + 1];
}

const configPath = resolve(argumentValue('--config') ?? 'config.local.json');
const amount = Number(argumentValue('--amount') ?? '1000');
const message = argumentValue('--message') ?? '';
const { config, baseDirectory } = await loadConfig(configPath);
const secret = process.env[config.bridge.secretEnvironmentName];
if (!secret || secret.length < 24) throw new Error(`Set ${config.bridge.secretEnvironmentName} before sending a test donation.`);

const bridge = new PalChzzkBridge(
  config,
  secret,
  new DonationRuleEngine(await loadRules(baseDirectory, config.rulesFile)),
  new LocalModClient(config.bridge.host, config.bridge.port, secret),
);

const result = await bridge.processDonation(makeAdminDonation(amount, message));
console.log(JSON.stringify(result, null, 2));
